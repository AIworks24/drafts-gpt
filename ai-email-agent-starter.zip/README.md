# AI Email Agent (Vercel + Supabase) — Starter Repo

Starter repo for Drafts-GPT.